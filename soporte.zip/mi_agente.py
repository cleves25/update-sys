import pyautogui
from flask import Flask, render_template_string, request, Response
import mss
import io
from PIL import Image, ImageDraw
import time
import logging
import threading
import subprocess
import requests
import re
import os
import signal
import sys

# --- CONFIGURACIÓN ---
ANCHO_VIDEO = 800       # Balance calidad/velocidad
CALIDAD_JPEG = 45       
MOSTRAR_CURSOR = True   
pyautogui.FAILSAFE = False # Evita cierres accidentales

# ¡¡¡ IMPORTANTE: PEGA TU URL DE DISCORD AQUÍ ABAJO !!!
DISCORD_WEBHOOK_URL = "https://discordapp.com/api/webhooks/1448014570827550892/Y3Fi7Mm8jueaWuxU5XlTRE8FBLFyqvgrtmtSYuRqnO7kfljuT5rfd_QxdLRANxw-uJLQ"

log = logging.getLogger('werkzeug')
log.setLevel(logging.ERROR)
app = Flask(__name__)

# --- INTERFAZ WEB (DISEÑO FINAL) ---
HTML_MASTER = """
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Soporte Remoto</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * { box-sizing: border-box; user-select: none; -webkit-tap-highlight-color: transparent; }
        body { margin: 0; background: #0f0f0f; color: white; font-family: 'Segoe UI', sans-serif; overflow: hidden; height: 100vh; display: flex; flex-direction: column; }
        
        #pantalla-container { flex-grow: 1; position: relative; background: #000; display: flex; justify-content: center; align-items: center; }
        #video-feed { width: 100%; height: 100%; object-fit: contain; pointer-events: none; }
        #touch-layer { position: absolute; top: 0; left: 0; width: 100%; height: 100%; z-index: 10; }

        .toolbar {
            position: fixed; bottom: 30px; left: 50%; transform: translateX(-50%);
            background: rgba(20, 20, 20, 0.9); backdrop-filter: blur(5px);
            padding: 10px 25px; border-radius: 30px; border: 1px solid #333;
            display: flex; gap: 25px; z-index: 100; box-shadow: 0 10px 30px rgba(0,0,0,0.5);
        }
        .btn-control { background: none; border: none; color: #ccc; font-size: 22px; display: flex; flex-direction: column; align-items: center; }
        .btn-control span { font-size: 9px; margin-top: 5px; font-weight: bold; }
        .btn-control:active { color: #00aaff; transform: scale(0.9); }
        .btn-danger { color: #ff4444; }

        #keyboard-area {
            display: none; position: fixed; bottom: 0; left: 0; width: 100%;
            background: #151515; border-top: 2px solid #00aaff; padding: 15px; z-index: 200;
        }
        .input-row { display: flex; gap: 10px; margin-bottom: 10px; }
        input[type="text"] { flex: 1; padding: 12px; border-radius: 8px; border: none; background: #333; color: white; font-size: 16px; outline: none; }
        .kb-btn { padding: 0 20px; border-radius: 8px; border: none; font-weight: bold; color: white; cursor: pointer; }
        .btn-blue { background: #007bff; } .btn-grey { background: #444; }
    </style>
</head>
<body>
    <div id="pantalla-container">
        <img id="video-feed" src="/video_feed">
        <div id="touch-layer"></div>
    </div>

    <div class="toolbar">
        <button class="btn-control" onclick="hacerClic('izq')"><i class="fa-solid fa-computer-mouse"></i><span>CLICK</span></button>
        <button class="btn-control" onclick="hacerClic('der')"><i class="fa-solid fa-computer-mouse"></i><span>MENU</span></button>
        <button class="btn-control" onclick="toggleKeyboard()"><i class="fa-solid fa-keyboard"></i><span>TECLAS</span></button>
        <button class="btn-control" onclick="teclaEspecial('enter')"><i class="fa-solid fa-turn-down fa-rotate-90"></i><span>ENTER</span></button>
        <button class="btn-control btn-danger" onclick="cerrarPrograma()"><i class="fa-solid fa-power-off"></i><span>OFF</span></button>
    </div>

    <div id="keyboard-area">
        <div style="text-align:center; color:#555; margin-bottom:10px;" onclick="toggleKeyboard()"><i class="fa-solid fa-chevron-down"></i></div>
        <div class="input-row">
            <input type="text" id="input-text" placeholder="Escribe mensaje...">
            <button class="kb-btn btn-blue" onclick="enviarTextoCompleto()"><i class="fa-solid fa-paper-plane"></i></button>
        </div>
        <div class="input-row">
             <button class="kb-btn btn-grey" style="flex:1" onclick="teclaEspecial('backspace')"><i class="fa-solid fa-delete-left"></i></button>
             <button class="kb-btn btn-grey" style="flex:1" onclick="teclaEspecial('space')">ESPACIO</button>
             <button class="kb-btn btn-grey" style="flex:1" onclick="teclaEspecial('win')"><i class="fa-brands fa-windows"></i></button>
        </div>
    </div>

    <script>
        const touchLayer = document.getElementById('touch-layer');
        let lastX = 0, lastY = 0;
        let lastSentTime = 0;
        const THROTTLE_DELAY = 30; // Anti-Flood

        touchLayer.addEventListener('touchstart', (e) => { 
            lastX = e.touches[0].clientX; lastY = e.touches[0].clientY; 
        }, {passive: false});

        touchLayer.addEventListener('touchmove', (e) => {
            e.preventDefault(); 
            let now = Date.now();
            if (now - lastSentTime < THROTTLE_DELAY) return;
            lastSentTime = now;

            let curX = e.touches[0].clientX; let curY = e.touches[0].clientY;
            let dx = (curX - lastX) * 2.2; 
            let dy = (curY - lastY) * 2.2;
            lastX = curX; lastY = curY;
            fetch(`/mover?x=${dx}&y=${dy}`, {method: 'POST', keepalive: true}).catch(e=>{});
        }, {passive: false});

        function enviarComando(url) {
            if(navigator.vibrate) navigator.vibrate(30);
            fetch(url, {method: 'POST', keepalive: true}).catch(e=>{});
        }
        function hacerClic(t) { enviarComando('/clic?tipo=' + t); }
        function teclaEspecial(k) { enviarComando('/tecla?k=' + k); }
        
        function toggleKeyboard() {
            let kb = document.getElementById('keyboard-area');
            let input = document.getElementById('input-text');
            if (kb.style.display === 'block') { kb.style.display = 'none'; input.blur(); } 
            else { kb.style.display = 'block'; input.focus(); }
        }
        function enviarTextoCompleto() {
            let input = document.getElementById('input-text');
            if (input.value.length > 0) {
                fetch('/escribir_frase?t=' + encodeURIComponent(input.value), {method: 'POST'});
                input.value = "";
            }
        }
        function cerrarPrograma() { 
            if(confirm("¿Cerrar conexión?")) {
                fetch('/apagar', {method: 'POST'});
                document.body.innerHTML = "<h1 style='text-align:center; color:#555; margin-top:50%'>OFFLINE</h1>";
            }
        }
    </script>
</body>
</html>
"""

# --- BACKEND ---

def generar_frames():
    with mss.mss() as sct:
        monitor = sct.monitors[1]
        while True:
            screenshot = sct.grab(monitor)
            img = Image.frombytes("RGB", screenshot.size, screenshot.bgra, "raw", "BGRX")
            
            if MOSTRAR_CURSOR:
                try:
                    mx, my = pyautogui.position()
                    rel_x = mx - monitor['left']
                    rel_y = my - monitor['top']
                    
                    draw = ImageDraw.Draw(img)
                    # DIBUJAR FLECHA (CURSOR)
                    puntos = [(rel_x, rel_y), (rel_x, rel_y+22), (rel_x+14, rel_y+14)]
                    # Borde negro
                    draw.polygon([(rel_x-1, rel_y-1), (rel_x-1, rel_y+24), (rel_x+16, rel_y+15)], fill="black")
                    # Relleno blanco
                    draw.polygon(puntos, fill="white")
                except: pass
            
            img.thumbnail((ANCHO_VIDEO, ANCHO_VIDEO))
            frame_buffer = io.BytesIO()
            img.save(frame_buffer, format='JPEG', quality=CALIDAD_JPEG)
            yield (b'--frame\r\nContent-Type: image/jpeg\r\n\r\n' + frame_buffer.getvalue() + b'\r\n')
            time.sleep(0.02)

@app.route('/')
def index(): return render_template_string(HTML_MASTER)

@app.route('/video_feed')
def video_feed(): return Response(generar_frames(), mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/mover', methods=['POST'])
def mover():
    try: pyautogui.moveRel(float(request.args.get('x')), float(request.args.get('y')), _pause=False)
    except: pass
    return ""

# HILOS (Anti-Freeze)
def tarea_clic(tipo):
    if tipo == 'izq': pyautogui.click()
    else: pyautogui.click(button='right')

@app.route('/clic', methods=['POST'])
def clic():
    threading.Thread(target=tarea_clic, args=(request.args.get('tipo'),)).start()
    return ""

def tarea_tecla(k): pyautogui.press(k)
@app.route('/tecla', methods=['POST'])
def tecla():
    threading.Thread(target=tarea_tecla, args=(request.args.get('k'),)).start()
    return ""

def tarea_escribir(t):
    if t: pyautogui.write(t, interval=0.01)
@app.route('/escribir_frase', methods=['POST'])
def escribir_frase():
    threading.Thread(target=tarea_escribir, args=(request.args.get('t'),)).start()
    return ""

@app.route('/apagar', methods=['POST'])
def apagar():
    os.kill(os.getpid(), signal.SIGTERM)
    return ""

# TÚNEL
def iniciar_tunel():
    CREATE_NO_WINDOW = 0x08000000
    try:
        process = subprocess.Popen(['cloudflared.exe', 'tunnel', '--url', 'http://localhost:5000'], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, creationflags=CREATE_NO_WINDOW)
        for line in process.stdout:
            match = re.search(r'https://[a-zA-Z0-9-]+\.trycloudflare\.com', line)
            if match: 
                requests.post(DISCORD_WEBHOOK_URL, json={"content": f"✅ **CONEXIÓN LISTA**\nLink: {match.group(0)}"})
                break
    except: pass

if __name__ == '__main__':
    threading.Thread(target=iniciar_tunel, daemon=True).start()
    app.run(host='0.0.0.0', port=5000, threaded=True)